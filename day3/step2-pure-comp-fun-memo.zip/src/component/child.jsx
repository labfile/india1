import { Component } from "react";

class ChildComp extends Component{
    shouldComponentUpdate(currentProps, currentState){
        if(currentProps.power === this.props.power ){
            return false
        }else{
            return true
        }
    }
    render(){
        console.log("Child Component was rendered", Math.random())
        return <div>
                    <h2> Child Component </h2>
                    <h3>Power is { this.props.power }</h3>
               </div>
    }
}

export default ChildComp;