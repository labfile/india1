import React from "react";

let FunComp = ({power})=>{
    console.log("Function Child Component was rendered", Math.random())
        return <div>
                    <h2> Function Child Component </h2>
                    <h3>Power is { power }</h3>
               </div>
}

export default React.memo(FunComp);