import { PureComponent } from "react";

class PureChildComp extends PureComponent{
    
    render(){
        console.log("Pure Child Component was rendered", Math.random())
        return <div>
                    <h2> Pure Child Component </h2>
                    <h3>Power is { this.props.power }</h3>
               </div>
    }
}

export default PureChildComp;