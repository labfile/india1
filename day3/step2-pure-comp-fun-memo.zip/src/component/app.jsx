import { Component } from "react";
import ChildComp from "./child";
import FunComp from "./fun.comp";
import PureChildComp from "./pure.child";

class App extends Component{
    state = {
        power : 0
    }
    render(){
        return <div>
                    <h1> App Component </h1>
                    <button onClick={ ()=> this.setState({ power : this.state.power + 1})}>Increase Power</button>
                    <button onClick={ ()=> this.setState({ power : 5})}>Set Power to 5</button>
                    <ChildComp power={ this.state.power }/>
                    <PureChildComp power={ this.state.power }/>
                    <FunComp power={ this.state.power }/>

                </div>
    }
}

export default App;


/* http://p.ip.fi/yu_1 */