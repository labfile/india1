import React from "react";

export let FamilyContext = React.createContext();
