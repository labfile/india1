import Grand from "./components/grand";

let MainApp = ()=>{ 
  return <div className="container">
            <h2>Context API</h2>
            <Grand/>
         </div>
}

export default MainApp;