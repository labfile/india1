import Child from "./child"

let Parent = ()=>{
    return <div style={ { padding : "10px" , margin : "10px", border : "2px solid grey"} }>
                <h2>Parent Component</h2>
                <Child/>
            </div>
}

export default Parent