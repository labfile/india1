import { FamilyContext } from "../contexts/family.context"

let Cousin = ()=>{
    return <div style={ { padding : "10px" , margin : "10px", border : "2px solid grey"} }>
                <h2>Cousin Component</h2>
                <FamilyContext.Consumer>{(value) => <h2>{value}</h2>}</FamilyContext.Consumer>
            </div>
}

export default Cousin