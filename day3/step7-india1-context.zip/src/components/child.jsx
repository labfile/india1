import { useContext } from "react"
import { FamilyContext } from "../contexts/family.context"

let Child = ()=>{
    let value = useContext(FamilyContext);
    return <div style={ { padding : "10px" , margin : "10px", border : "2px solid grey"} }>
                <h2>Child Component</h2>
              {/*   
                <FamilyContext.Consumer>{(value) => <h2>{value}</h2> }</FamilyContext.Consumer>
                <FamilyContext.Consumer>{(value) => <h2>{value}</h2> }</FamilyContext.Consumer>
                <FamilyContext.Consumer>{(value) => <h2>{value}</h2> }</FamilyContext.Consumer>
                <FamilyContext.Consumer>{(value) => <h2>{value}</h2> }</FamilyContext.Consumer>
                <FamilyContext.Consumer>{(value) => <h2>{value}</h2> }</FamilyContext.Consumer>
                <FamilyContext.Consumer>{(value) => <h2>{value}</h2> }</FamilyContext.Consumer> 
              */}
                <h2>{ value }</h2>
                <h2>{ value.toUpperCase() }</h2>
                <h2>{ value.length }</h2>
                <h2>{ value.length * 5 }</h2>
            </div>
}

export default Child