import { useRef } from "react"
import { useState } from "react"
import { FamilyContext } from "../contexts/family.context"
import Cousin from "./cousin"
import Parent from "./parent"

let Grand = ()=>{
    let ti = useRef();
    let [message, setMessage] = useState("empty message"); 
    return <div style={ { padding : "10px" , margin : "10px", border : "2px solid grey"} }>
                <h2>Grand Component</h2>
                <input ref={ti} type="text" />
                <button onClick={()=> setMessage(ti.current.value)}>Set Message</button>
                <FamilyContext.Provider value={message}>
                    <Parent/>
                    <Cousin/>
                </FamilyContext.Provider>
            </div>
}

export default Grand