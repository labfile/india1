import { combineReducers, createStore } from 'redux';
import { heroReducer } from './hero/heroReducer';
import { movieReducer } from './movie/movieReducer';
// import { devToolsEnhancer  } from '@redux-devtools/extension';



const rootReducer = combineReducers({
    heroes : heroReducer,
    movies : movieReducer
})

const store = createStore( rootReducer );
// const store = createStore( rootReducer, devToolsEnhancer() );

export default store;