import { ADD_MOVIE, REMOVE_MOVIE } from "./movieType"

export const addMovie = ()=>{
    return {
        type : ADD_MOVIE
    }
}
export const removeMovie = ()=>{
    return {
        type : REMOVE_MOVIE
    }
}