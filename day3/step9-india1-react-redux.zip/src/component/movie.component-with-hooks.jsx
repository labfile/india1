import { addMovie, removeMovie } from "../redux"
import { useDispatch, useSelector } from "react-redux";

let MovieCompHooks = ()=>{
    const numOfMovies = useSelector( state =>  state.movies.numOfMovies );
    const dispatch = useDispatch();
    return <div>
                <h2>Movies Management Program</h2>
                <h3>Number of Movies : { numOfMovies }</h3>
                <button onClick={ ()=>dispatch( addMovie() ) }>Add Movie</button>
                <button onClick={ ()=>dispatch( removeMovie() ) }>Remove Movie</button>
            </div>
}


export default MovieCompHooks;