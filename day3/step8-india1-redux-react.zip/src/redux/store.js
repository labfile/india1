import { legacy_createStore } from "redux";
import { heroReducer } from "./hero/hero.reducers";

const store = legacy_createStore( heroReducer );

export default store;