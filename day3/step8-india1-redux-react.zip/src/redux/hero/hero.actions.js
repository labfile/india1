import { ADD_HERO } from "./hero.types"

export const addHero = ()=> {
    return {
        type : ADD_HERO
    }
}