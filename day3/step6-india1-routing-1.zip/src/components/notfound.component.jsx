let NotFoundComp = ()=>{
   
    return <div>
                <h2>404 | Requested Page Not Found Component</h2>
            </div>
}

export default NotFoundComp;