let SupermanComp = ()=>{
   
    return <div>
                <h2>Superman Component</h2>
            </div>
}

export default SupermanComp;