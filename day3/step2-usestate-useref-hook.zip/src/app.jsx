import { Component } from "react";
import ChildComp from "./child.component";
import HeroList from "./herolist.component";

class App extends Component{
    render(){
        return <div>
                    <h1>Welcome to your life</h1>
                    <ChildComp/>
                    <hr />
                    <HeroList/>
                </div>
    }
}

export default App;