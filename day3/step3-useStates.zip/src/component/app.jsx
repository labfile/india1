import { Component } from "react";
import Child from "./child";
import FunChild from "./fun";
import UseStateMultiProps from "./useStatemultiprops";
import UseStateObject from "./useStateObject";

class App extends Component{
    render(){
        return <div>
                    <h1> Hooks in react </h1>
                    <Child/>    
                    <FunChild/>
                    <UseStateObject/>
                    <UseStateMultiProps/>
                </div>
    }
}

export default App;