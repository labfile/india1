import { useRef } from "react";
import { useState } from "react";

let UseStateMultiProps = ()=>{
    let [herofirstname, changeHeroFirstInfo] = useState({lastname : ""});
    let [herolastname, changeHeroLastInfo] = useState({firstname : ""});
    let ip1 = useRef()
    let ip2 = useRef()
    return <div>
                <h1>Function Array with UseState hook</h1>
                <input ref={ ip1 } type="text" />
                <button onClick={()=> { changeHeroFirstInfo({firstname : ip1.current.value }); ip1.current.value = ''} }>Add Hero First Info</button>
                <input ref={ ip2 } type="text" />
                <button onClick={()=> { changeHeroLastInfo({lastname : ip2.current.value }); ip2.current.value = ''} }>Add Hero Last Info</button>
                <ul>
                    <li>First name : { herofirstname.firstname }</li>
                    <li>Last name : { herolastname.lastname }</li>
                </ul>
            </div>
}
export default UseStateMultiProps
