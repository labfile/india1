import { useRef } from "react";
import { useState } from "react";

let UseStateObject = ()=>{
    let [avengers, addAvenger] = useState(['ironman']);
    let ip = useRef()
    return <div>
                <h1>Function Array with UseState hook</h1>
                <input ref={ ip } type="text" />
                <button onClick={()=> { addAvenger([...avengers, ip.current.value]); ip.current.value = ''} }>Add Avenger</button>
                <ol>
                    {
                        avengers.map((val, idx)=><li key={idx}>{ val }</li>)
                    }
                </ol>
            </div>
}
export default UseStateObject
