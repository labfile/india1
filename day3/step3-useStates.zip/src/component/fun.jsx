import { useState } from "react";

let FunChild = ()=>{
    // console.log( useState() );
    let [power, setPower] = useState(0);
    return <div>
                <h1>Function Component with UseState hook</h1>
                <h2>Power : { power }</h2>
                <button onClick={()=> setPower(power+1) }>Increase Power</button>
            </div>
}
export default FunChild
