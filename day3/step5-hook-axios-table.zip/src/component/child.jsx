import { useEffect, useState } from "react";
import axios from "axios";
import { internaldata } from "./data"; 

let Child = (props)=> {
    let [users, setUsers] = useState([])
    useEffect(()=>{
        // console.log("component was mounted ", Math.random())
        // axios.get("https://reqres.in/api/users?page=1")
        // .then(res => setUsers(res.data.data))
        // .catch(err => console.log("Error ", err))
    },[])

    useEffect(()=>{
        console.log("component's power was updated ", Math.random())
    },[props.power]);
    
    useEffect(()=>{
        return ()=>{
            console.log("component was unmounted ")
        }
    },[]);

    let clickHandler = ()=>{
        axios.get("https://reqres.in/api/users?page=5")
        .then(res => setUsers(res.data.data))
        .catch(err => {
            setUsers(internaldata.data);
            console.log("Error ", err)
        })
        
    }

/*     
    useEffect(()=>{
        console.log("component's power was updated ", Math.random())
        console.log("component was mounted ", Math.random())
        return ()=>{
            console.log("component was unmounted ")
        }
    },[props.power]) 
*/
    return <div className="container">
                <h2>Users List </h2>
                <button onClick={ clickHandler }>Get Users</button>
                <table className="table table-sm table-responsive table-striped table-hover">
                    <thead className="table-dark">
                        <tr>
                            <th>Sl #</th>
                            <th>Photo</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>eMail id</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                    {
                        users.map(user => <tr key={user.id}>
                            <td>{ user.id }</td>
                            <td>
                            <img className="rounded" width="50" src={user.avatar} alt={user.first_name} />
                            </td>
                            <td>
                            {user.first_name}
                            </td>
                            <td>
                            {user.last_name}
                            </td>
                            <td>
                            {user.email}
                            </td>
                            <td>
                                <button className="btn btn-warning">Edit</button>
                            </td>
                            <td>
                                <button className="btn btn-danger">Delete</button>
                            </td>
                        </tr>)
                }
                </tbody>
                </table>
           </div>
}

export default Child;


/* http://p.ip.fi/0pGe */