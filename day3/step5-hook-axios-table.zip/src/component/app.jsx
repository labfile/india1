import { useState } from "react";
import Child from "./child";

let App = ()=> {
    let [state,setState] = useState(0)
    return <div>
                <h1> Use Effect hook </h1>
                <button onClick={()=> setState(state+1)}>Increase Power</button>
                { state < 20 && <Child power={ state }/> }
           </div>
}

export default App;