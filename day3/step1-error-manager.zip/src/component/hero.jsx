import { Component } from "react";

class HeroComp extends Component{
    state = {
        title : "Hero Component",
    }
    render(){
        if(this.props.power < 5){
            throw new Error("Hero power is less than 5");
        }else{
            return <div>
                        <h2>{ this.state.title } Power is { this.props.power }</h2>
                   </div>
        }
    }
}
export default HeroComp;