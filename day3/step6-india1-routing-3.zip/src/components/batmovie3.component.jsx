let BatMovie3Comp = ()=>{
    return <div>
                <h2>Batman Movie 3 Component</h2>
                <h3>The Dark Knight Rises</h3>
            </div>
}

export default BatMovie3Comp;