import React, { Component } from "react";

class Child extends Component{
    ipref = React.createRef();
    render(){
        return <div>
                <h1> Child Component </h1>
                <h2>Power is { this.props.power }</h2>
                <input ref={ this.ipref } type="text" />
                <button onClick={()=> this.props.changeMessageHandler( this.ipref.current.value ) }>Change Message</button>
            </div>
    }
}

export default Child;

/* http://p.ip.fi/W08- */