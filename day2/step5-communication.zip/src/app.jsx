import { Component } from "react";
import Child from "./components/child";

class App extends Component{
    state = {
        power : 0,
        message : 'empty'
    }
    changeMessageHandler = (nmessage)=>{
        this.setState({
            message : nmessage
        })
    }
    render(){
        return <div className="container">
            <h1> Power is : { this.state.power } | Message : { this.state.message }</h1>
            <input type="range" onChange={(event)=> this.setState({ power : Number(event.target.value) })} />
            <hr />
            <Child changeMessageHandler={ this.changeMessageHandler } power={ this.state.power }/>
        </div>
    }
}

export default App;


/* http://p.ip.fi/pqxJ */