export let parastyle = { backgroundColor : "crimson" , fontFamily:"sans-serif", padding : Math.round(  Math.random() * 50 )+"px", color : "papayawhip" }
