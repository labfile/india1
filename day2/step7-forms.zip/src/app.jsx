import { Component } from "react";

/*
Hero
Age
City 
Power 
*/

class App extends Component{
    state = {
        hname : "Batman",
        hage : 0,
        hcity : "",
        hpower : 0,
        nameErrorMessage : "",
        ageErrorMessage : "",
        powerErrorMessage : "",
        cityErrorMessage : "",
    }
   /*  
   nameChangeHandler = (evt)=>{
        this.setState({
            hname : evt.target.value
        })
    }
    ageChangeHandler = (evt)=>{
        this.setState({
            hage : evt.target.value
        })
    }
    cityChangeHandler = (evt)=>{
        this.setState({
            hcity : evt.target.value
        })
    }
    powerChangeHandler = (evt)=>{
        this.setState({
            hpower : evt.target.value
        })
    } 
    */
    changeHandler = (evt)=>{
        this.setState({
            [evt.target.getAttribute("name")]: evt.target.value
        })
    }
    formSubmitHandler = (evt)=>{
        evt.preventDefault();
        if(this.state.hage < 18){
            this.setState({ ageErrorMessage : "you are too young to join us" })
        }else if(this.state.hage > 90){
            this.setState({ ageErrorMessage : "you are too old to join us" })
        }else{
            this.setState({ 
                hname : "Batman",
                hage : 0,
                hcity : "",
                hpower : 0,
                nameErrorMessage : "",
                ageErrorMessage : "",
                powerErrorMessage : "",
                cityErrorMessage : ""
             });
            evt.target.submit();
        }
    }
    render(){
        return <div className="container">
                    <h1> New User Registeration Form </h1>
                    <form onSubmit={ this.formSubmitHandler } action="#" method="get">
                    <div className="mb-3">
                        <label htmlFor="hname" className="form-label">Your Name</label>
                        <input name="hname" onChange={ this.changeHandler } value={ this.state.hname } type="text" className="form-control" id="hname"/>
                        { this.state.nameErrorMessage !== "" && <div className="form-text">Please fill your name</div>}
                    </div>
                    
                    <div className="mb-3">
                        <label htmlFor="hage" className="form-label">Your Age</label>
                        <input name="hage" onChange={ this.changeHandler } value={ this.state.hage } type="number" className="form-control" id="hage"/>
                         { this.state.ageErrorMessage !== "" && <div  className="form-text text-danger">{ this.state.ageErrorMessage }</div> }
                    </div>
                    
                    <div className="mb-3">
                        <label htmlFor="hcity" className="form-label">Your City</label>
                        <input name="hcity" onChange={ this.changeHandler } value={ this.state.hcity } type="text" className="form-control" id="hcity"/>
                         { this.state.cityErrorMessage !== "" && <div className="form-text">Please fill your city</div> }
                    </div>
                    
                    <div className="mb-3">
                        <label htmlFor="hpower" className="form-label">Power</label>
                        <input name="hpower" onChange={ this.changeHandler } value={ this.state.hpower } type="range" min="0" max="10" className="form-control" id="hpower"/>
                         { this.state.powerErrorMessage !== "" && <div className="form-text">Please fill your power</div> }
                    </div>
                    
                    <button type="submit" className="btn btn-primary">Submit</button>
                    </form>
                    <hr />
                    <ul>
                        <li> Hero Name : { this.state.hname } </li>
                        <li> Hero Age : { this.state.hage }</li>
                        <li> Hero City : { this.state.hcity } </li>
                        <li> Hero Power : { this.state.hpower } </li>
                    </ul>
                </div>
    }
}

export default App;


/* http://p.ip.fi/FJqj */