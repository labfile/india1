import { Component } from "react";

class HeroApp extends Component{
    render(){
        return <div className="col-sm-4">
            <h1>{ this.props.title } </h1>
            <ol className="list-group">{ 
            this.props.list.map((val, idx)=> <li className="list-group-item" key={idx}>{ val }</li> ) }
            </ol>
        </div>
    }
}

export default HeroApp;

/* http://p.ip.fi/7s4R */