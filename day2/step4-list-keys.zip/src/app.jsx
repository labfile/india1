import React, { Component } from "react";
import HeroApp from "./components/hero";

class App extends Component{
    state = {
        avengers : [],
        justiceleague : [],
        indicheroes : []
    }
    avenger = React.createRef();
    justice = React.createRef();
    indic = React.createRef();
    addAvenger = ()=>{
        this.setState(
            { avengers : [...this.state.avengers, this.avenger.current.value ] 
            });
        this.avenger.current.value = '';
    };
    addIndicHero = ()=>{
        this.setState(
            { indicheroes : [...this.state.indicheroes, this.indic.current.value ] 
            });
        this.indic.current.value = '';
    };
    addJusticeLeague = ()=>{
        this.setState(
            { justiceleague : [...this.state.justiceleague, this.justice.current.value ] 
            });
        this.justice.current.value = '';
    };
    render(){
        return <div className="container">
            <h1> Heroes Application </h1>

            <div className="row">
            <div className="card mb-5 col-lg-4 col-md-6">
                <div className="card-body">
                    <h5 className="card-title">Add Avenger</h5>
                    <label htmlFor="">Enter New Hero : </label>
                    <input className="form-control mb-3" ref={this.avenger} type="text"/>
                    <button className="btn btn-primary" onClick={ this.addAvenger }>Add Avenger</button>
                </div>
            </div>

            <div className="card mb-5  col-lg-4 col-md-6">
                <div className="card-body">
                    <h5 className="card-title">Add Justice League Hero</h5>
                    <label htmlFor="">Enter New Justice League hero : </label>
                    <input className="form-control mb-3" ref={this.justice} type="text"/>
                    <button className="btn btn-primary" onClick={ this.addJusticeLeague }>Add Justice League</button>
               </div>
            </div>

            <div className="card mb-5  col-lg-4  col-md-12">
                <div className="card-body">
                    <h5 className="card-title">Add Indic Hero Hero</h5>
                    <label htmlFor="">Enter New Indic hero : </label>
                    <input className="form-control mb-3" ref={this.indic} type="text"/>
                    <button className="btn btn-primary" onClick={ this.addIndicHero }>Add Indic Hero</button>
                </div>
            </div>
            </div>

            <hr />
            <div className="row">
            <HeroApp title="Avengers" list={ this.state.avengers }></HeroApp>
            <HeroApp title="Justice League" list={ this.state.justiceleague }></HeroApp>
            <HeroApp title="Indic Heroes" list={ this.state.indicheroes }></HeroApp>
            </div>
        </div>
    }
}

export default App;


/* http://p.ip.fi/VLeq */

/* http://p.ip.fi/Y1cW */