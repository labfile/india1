import { Component } from "react";

class App extends Component{
    state = {
        show : false
    }
    render(){
            return <div>
                    <h1> App Component | Terms are now shown : { this.state.show+"" } </h1>
                    <label htmlFor="show">Show Terms & Conditions</label>
                    <input onChange={()=> this.setState({ show : !this.state.show})} id="show" type="checkbox" />
                    {
                        this.state.show  && <fieldset>
                        <legend>Terms & Conditions</legend>
                        <p>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Vero libero saepe incidunt accusamus cumque illum vitae repudiandae iure, voluptate neque natus necessitatibus praesentium minus sit at ipsam, ipsa nobis sapiente!
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus voluptatibus dicta sunt maiores consequatur praesentium eius ipsa necessitatibus, eum aspernatur similique aliquam distinctio vero nulla reiciendis deserunt non recusandae nihil.
                            Lorem ipsum dolor sit amet consectetur, adipisicing elit. Doloremque aspernatur a inventore sit corporis iusto, consectetur, mollitia quam dolorem hic labore nihil explicabo sunt cupiditate accusamus natus! Maxime, in nostrum?
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Saepe sunt sint maiores debitis, totam cumque sit molestias, deleniti libero ea, doloribus alias mollitia ratione modi? Magni libero nihil blanditiis quia?
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Recusandae quibusdam nihil, harum velit eligendi repellendus mollitia aperiam veniam quam sapiente sunt voluptatibus numquam vitae? Recusandae voluptatum itaque nostrum non assumenda?
                        </p>
                    </fieldset>
                    }
               </div>
    }
}

export default App;


/* http://p.ip.fi/Q8BZ */