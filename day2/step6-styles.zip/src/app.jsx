import { Component } from "react";
import { parastyle } from "./parastyle";
import "./extstyle.css";
class App extends Component{
    render(){
        return <div>
                    <h1> Welcome to your life </h1>
                    <p style={ parastyle }>
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolor facilis similique temporibus rem, dolore, dicta aut amet illum cumque eligendi tenetur laboriosam voluptas repudiandae, pariatur aliquid eveniet culpa esse voluptatum?
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Maiores officia minus deleniti nam qui rem nihil, dolore id officiis exercitationem cum in voluptatibus saepe dolorum temporibus ex. At, voluptatibus totam?
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque soluta nulla quos vel provident, ipsam voluptatum fugit dolores et consequatur, expedita veritatis aperiam reiciendis tempore culpa in atque, nisi cum.
                    </p>
                    <p style={ {...parastyle, backgroundColor : "darkorange"} }>
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolor facilis similique temporibus rem, dolore, dicta aut amet illum cumque eligendi tenetur laboriosam voluptas repudiandae, pariatur aliquid eveniet culpa esse voluptatum?
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Maiores officia minus deleniti nam qui rem nihil, dolore id officiis exercitationem cum in voluptatibus saepe dolorum temporibus ex. At, voluptatibus totam?
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque soluta nulla quos vel provident, ipsam voluptatum fugit dolores et consequatur, expedita veritatis aperiam reiciendis tempore culpa in atque, nisi cum.
                    </p>
                    <p style={ {...parastyle, backgroundColor : "darkslateblue"} }>
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolor facilis similique temporibus rem, dolore, dicta aut amet illum cumque eligendi tenetur laboriosam voluptas repudiandae, pariatur aliquid eveniet culpa esse voluptatum?
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Maiores officia minus deleniti nam qui rem nihil, dolore id officiis exercitationem cum in voluptatibus saepe dolorum temporibus ex. At, voluptatibus totam?
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque soluta nulla quos vel provident, ipsam voluptatum fugit dolores et consequatur, expedita veritatis aperiam reiciendis tempore culpa in atque, nisi cum.
                    </p>
                    <p style={ {...parastyle, backgroundColor : "darkkhaki", borderRadius : "20px"} }>
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolor facilis similique temporibus rem, dolore, dicta aut amet illum cumque eligendi tenetur laboriosam voluptas repudiandae, pariatur aliquid eveniet culpa esse voluptatum?
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Maiores officia minus deleniti nam qui rem nihil, dolore id officiis exercitationem cum in voluptatibus saepe dolorum temporibus ex. At, voluptatibus totam?
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque soluta nulla quos vel provident, ipsam voluptatum fugit dolores et consequatur, expedita veritatis aperiam reiciendis tempore culpa in atque, nisi cum.
                    </p>
               </div>
    }
}

export default App;