import { Component } from "react";
import AnotherPowerComp from "./components/anotherpowercomp";
import PowerComp from "./components/powercomp";

class App extends Component{
    render(){
        return <div>
                    <h1> Higher Order Components</h1>
                    <PowerComp headcount={ 50 } city="bangalore"/>
                    <AnotherPowerComp headcount={ 250 } city="mumbai"/>
                </div>
    }
}

export default App;