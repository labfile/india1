import { Component } from "react";

let WithPower = (OriginalComponent)=>{
    class TempComp extends Component{
        state = {
            power : 0,
            version : 10
        }
        increasePower = ()=>{
            this.setState({
                power : this.state.power + 1
            })
        }
        render(){
            //return <OriginalComponent version={ this.state.version } increasePower={ this.increasePower } power={this.state.power} title="hello from hoc"/>
            return <OriginalComponent { ...this.props } {...this.state } increasePower={ this.increasePower } title="hello from hoc"/>
        }
    }
    return TempComp
}

export default WithPower;