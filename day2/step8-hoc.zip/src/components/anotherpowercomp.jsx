import { Component } from "react";
import WithPower from "./withpower";

class AnotherPowerComp extends Component{
    render(){
        return <div>
                    <h1> Hello from Another Power comp </h1>
                    <h5>{ this.props.title } headcount is { this.props.headcount } </h5>
                    <h2>Power is : { this.props.power }</h2>
                    <h2>Version is : { this.props.version }</h2>
                    <h2>city is : { this.props.city }</h2>
                    <button onClick={ this.props.increasePower }>Increase Power</button>
               </div>
    }
}

export default WithPower(AnotherPowerComp);