import { Component } from "react";
import FirstComp from "./components/first";

class App extends Component{
    state = {
        power : 100,
        version : 10001,
        title : "Hello from App",
    }
    render(){
        return <div>
                    <h1> Welcome to your life </h1>
                    <FirstComp power={ this.state.power } version={ this.state.version } title={ this.state.title }/>
                    <FirstComp power={101110} version={ this.state.version } title={ this.state.title }/>
                    <FirstComp power={ this.state.power } version={101111111111} title={ this.state.title }/>
                    <FirstComp power={ this.state.power } title="placeholder text" version={ this.state.version }/>
                    <FirstComp power={ 2 } version={5} title="dummy text"/>
                </div>
    }
}

export default App;


/* http://p.ip.fi/Els6 */