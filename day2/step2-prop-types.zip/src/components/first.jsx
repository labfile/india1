import { Component } from "react";
import PropTypes from "prop-types";

class FirstComp extends Component{
    /* static defaultProps = {
        power : 0,
        version : 10,
        title : "default title"
    } */
    static propTypes = {
        power : PropTypes.number.isRequired,
        version : PropTypes.number.isRequired,
        title : PropTypes.string.isRequired
    }
    render(){
        return <div style={ {border : "2px solid red", padding : "10px", margin:"10px"} }>
                <h1> First Component </h1>
                {/*             
                <h2>Power : { this.props.power || 0 }</h2>
                <h2>Version : { this.props.version || 10 }</h2>
                <h2>Title : { this.props.title || "dummy title"}</h2> 
                */}
                <h2>Power : { this.props.power  }</h2>
                <h2>Version : { this.props.version  }</h2>
                <h2>Title : { this.props.title }</h2>
               </div>
    }
}
/* FirstComp.defaultProps = {
    power : 0,
    version : 10,
    title : "default title"
} */
export default FirstComp;


/* http://p.ip.fi/QNyT */