import React, { Component } from "react";
// import { Fragment } from "react";

class App extends Component{
    state = {
        power : 0,
        version : 0
    }
    numref = React.createRef()
    /* 
    constructor(){
        super();
        this.increasePower = this.increasePower.bind(this);
    } 
    */
    /*     increasePower(){
        // alert("you clicked the button");
        this.power = this.power+1;
        console.log(this.power);
        this.forceUpdate();
    } */
    increasePower = () => {
        this.setState({
            power : this.state.power + 1
        })
    }
    increasePowerFromRange = (evt) => {
        this.setState({
            power : Number(evt.target.value)
        })
    }
    setPowerFromNumber = ()=>{
       /*  this.setState({
            power : Number(  document.getElementById("num").value )
        }) */
        this.setState({
            power : Number( this.numref.current.value )
        })
    }
    render(){
        return <div>
                    <h1> Hero application </h1>
                    <h2>Power : { this.state.power }</h2>
                    <h2>Version : { this.state.version }</h2>
                   {/*  <button onClick={ this.increasePower.bind(this) }>Increase Power</button> */}
                    <button onClick={ this.increasePower }>Increase Power</button>
                    <br />
                    <input min="0" step="5" max="50" onChange={ (event)=> this.increasePowerFromRange(event) } type="range"/>
                    <br />
                    {/* <input  id="num" type="number" /> */}
                    <input ref={this.numref} type="number" />
                    <button onClick={ this.setPowerFromNumber }>Set Power</button>
                    <br/>
                    <button onClick={()=> this.setState({ version : Math.round(Math.random() * 100 ) })}>Random Version</button>
               </div>
    }
}



/* let App = function(){
    return <div>
            <h1> Welcome to your life </h1>
        </div>
} */

/* 
let App = ()=> <>
                <div>
                    <h1> Welcome to your life </h1>
                </div>
                <div>
                    <h1> Welcome to your life </h1>
                </div>
                <label htmlFor="agree">Agree to terms</label>
                <input id="agree" type="checkbox" />
                </> */

export default App;


/* http://p.ip.fi/3KwD */ 


/* http://p.ip.fi/SN1Q */


/* http://p.ip.fi/vsW6 */