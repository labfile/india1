import React from "react";
import { createRoot } from "react-dom/client";
import App from "./app";

// let elm = React.createElement("h1",null,"welcome to your life");
createRoot(document.getElementById("root"))
.render(<App/>)